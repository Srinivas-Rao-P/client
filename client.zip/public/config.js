export const API_URL = "http://localhost:8081/api/"
