<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        <v-stepper v-model="el">
          <v-stepper-header>
            <v-stepper-step :complete="el > 1" step="1" @click="el = 1">
              Basic Information
            </v-stepper-step>

            <v-divider></v-divider>

            <v-stepper-step :complete="el > 2" step="2" @click="el = 2">
              Qualification
            </v-stepper-step>

            <v-divider></v-divider>

            <v-stepper-step :complete="el > 3" step="3" @click="el = 3">
              Employment History
            </v-stepper-step>

            <v-divider></v-divider>

            <v-stepper-step step="4" @click="el = 4"> Others </v-stepper-step>
          </v-stepper-header>

          <v-stepper-items>
            <v-stepper-content step="1">
              <v-row>
                <v-col cols="12" lg="4">
                  <span>First name</span>
                  <v-text-field
                    placeholder="First name"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="firstName"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="4">
                  <span>Last Name</span>
                  <v-text-field
                    placeholder="Last Name"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="lastName"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="4">
                  <span>Email</span>
                  <v-text-field
                    placeholder="Email"
                    color="primary"
                    hide-details="auto"
                    disabled
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="email"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="4">
                  <span>Phone</span>
                  <v-text-field
                    placeholder="Phone"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="phone"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="8" md="8">
                  <span>Address</span>
                  <v-text-field
                    placeholder="Address"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="addresss"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="4" md="4">
                  <span>State</span>
                  <v-text-field
                    placeholder="State"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="state"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="4" md="4">
                  <span>city</span>
                  <v-text-field
                    placeholder="city"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="city"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="4" md="4">
                  <span>Zip code</span>
                  <v-text-field
                    placeholder="Zip code"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="zipcode"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="4" md="4">
                  <span>Nationality</span>
                  <v-text-field
                    placeholder="Nationality"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="nationality"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="4" md="4">
                  <span>Date of birth</span>
                  <v-text-field
                    placeholder="Date of birth"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="dob"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="4" md="4">
                  <span>Gender</span>
                  <v-text-field
                    placeholder="Gender"
                    color="primary"
                    class="white"
                    hide-details="auto"
                    dense
                    flat
                    outlined
                    v-model="gender"
                  ></v-text-field>
                </v-col>
              </v-row>
            </v-stepper-content>

            <v-stepper-content step="2">
              <v-row>
                <v-col cols="12" lg="6">
                  <span>Level of education</span>
                  <v-text-field
                    placeholder="Level of education"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="levelOfEducation"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="6">
                  <span>Exam/Degree Title</span>
                  <v-text-field
                    placeholder="Exam/Degree Title"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="degree"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="6">
                  <span>Year of passing</span>
                  <v-text-field
                    placeholder="Year of passing"
                    color="primary"
                    hide-details="auto"
                    disabled
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="yop"
                  ></v-text-field>
                </v-col>
                <v-col cols="12" lg="6">
                  <span>Institute name</span>
                  <v-text-field
                    placeholder="Institute name"
                    color="primary"
                    hide-details="auto"
                    class="white"
                    dense
                    flat
                    outlined
                    v-model="institute"
                  ></v-text-field>
                </v-col>

                <v-col cols="auto">
                  <v-btn color="primary" outlined dense> Add education </v-btn>
                </v-col>
              </v-row>
            </v-stepper-content>

            <v-stepper-content step="3">
              <v-row> </v-row>
            </v-stepper-content>

            <v-stepper-content step="4"> </v-stepper-content>
          </v-stepper-items>
        </v-stepper>
      </v-col>
    </v-row>
    <v-row justify="end">
      <v-col cols="auto">
        <v-btn text v-if="el > 1" @click="next(-1)"> Back </v-btn>
      </v-col>
      <v-col cols="auto">
        <v-btn color="primary" v-if="el == 4"> Save </v-btn>
        <v-btn color="primary" v-else @click="next(1)"> Next </v-btn>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import VueJwtDecode from "vue-jwt-decode";
export default {
  name: "candidatelogin",
  props: {
    candidateToken: {
      type: String,
      requied: true,
    },
  },
  data() {
    return {
      firstName: "",
      lastName: "",
      phone: "",
      addresss: "",
      state: "",
      city: "",
      zipcode: "",
      nationality: "",
      dob: "",
      gender: "",
      el: 1,
    };
  },
  computed: {
    decoded() {
      return VueJwtDecode.decode(this.candidateToken);
    },
    email() {
      return this.decoded.email;
    },
  },
  methods: {
    next(index) {
      this.el = this.el + index;
    },
  },
};
</script>

<style>
</style>