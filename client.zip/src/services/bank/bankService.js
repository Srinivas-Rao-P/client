import resourcesServer from "@/services/config/resourcesServerConfig";

export const getBankList = (personId) => {
    return resourcesServer.get(`/bank/getBankList/${personId}`);
}
export const addBank = (data) => {
    return resourcesServer.post("/bank/addBank", data);
}
export const updateBank = (data) => {
    return resourcesServer.put("/bank/updateBank", data);
}
export const create = () => {
    return resourcesServer.get("/bank/create");
}
export const getBankData = (bankId) => {
    return resourcesServer.get(`/bank/getBankData/${bankId}`);
}