<template>
  <v-container>
    <v-row no-gutters>
      <v-col cols="12">
        <div>PageNotFound</div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {};
</script>

<style>
</style>