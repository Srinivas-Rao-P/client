<template>
  <v-row>
      <v-col>
          <div>My contact info</div>
      </v-col>
  </v-row>
</template>

<script>
export default {
    name:"mycontactinfo"
}
</script>

<style>

</style>