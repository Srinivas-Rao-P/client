<template>
  <v-form ref="form" lazy-validation @submit.prevent="saveBank" class="pa-12">
    <v-row justify="center">
      <v-col cols="12" lg="6" md="6">
        <v-row>
          <v-col cols="12">
            <span>Bank name</span>
            <v-text-field
              v-model="bankData.bankname"
              placeholder="Bank Name"
              required
              outlined
              solo
              dense
              flat
              hide-details="auto"
            ></v-text-field>
          </v-col>
          <v-col cols="12">
            <span>Type</span>
            <v-select
              :items="bankTypes"
              v-model="bankData.type"
              :disabled="isEditMode"
              item-text="type"
              item-value="id"
              placeholder="Type"
              required
              outlined
              solo
              dense
              flat
              hide-details="auto"
            ></v-select>
          </v-col>

          <v-col cols="12">
            <span>Account Number</span>
            <v-text-field
              v-model="bankData.accountnumber"
              placeholder="Account Number"
              required
              outlined
              solo
              dense
              flat
              hide-details="auto"
            ></v-text-field>
          </v-col>

          <v-col cols="12">
            <span>IFSC</span>
            <v-text-field
              v-model="bankData.ifsccode"
              placeholder="IFSC"
              required
              outlined
              solo
              dense
              flat
              hide-details="auto"
            ></v-text-field>
          </v-col>
        </v-row>

        <v-row>
          <v-col cols="12">
            <v-row>
              <v-col cols="auto">
                <v-btn type="submit" color="primary" depressed dark dense small>
                  Save
                </v-btn>
              </v-col>
              <v-col cols="auto">
                <v-btn
                  color="primary"
                  depressed
                  outlined
                  dark
                  dense
                  small
                  text
                  @click="cancel()"
                >
                  cancel
                </v-btn>
              </v-col>
            </v-row>
          </v-col>
        </v-row>
      </v-col>
    </v-row>
  </v-form>
</template>
<script>
import { create, addBank, getBankData, updateBank } from "@/services/bank/bankService.js";
export default {
  name: "Bankform",
  data() {
    return {
      bankData: {
        bankname: "",
        accountnumber: "",
        type: "",
        ifsccode: "",
      },
      nameRules: [(v) => !!v || "Please enter a name"],
      emailRules: [
        (v) => !!v || "Please enter a valid email",
        (v) => /.+@.+\..+/.test(v) || "E-mail must be valid",
      ],
      bankTypes: [],
    };
  },
  props: {
    id: {
      type: Number,
    },
    mode: {
      type: String,
      default: "add",
    },
  },
  computed: {
    isEditMode() {
      return this.mode === "edit";
    },
    isAddMode() {
      return this.mode === "add";
    },
  },
  components: {},
  watch: {},
  mounted() {},
  methods: {
    saveBank() {
      if (this.$refs.form.validate()) {
        if (this.isAddMode) {
          addBank(this.bankData)
            .then(() => {
              this.$refs.form.reset();
              this.$emit("done");
            })
            .catch((error) => {
              console.log(error);
            });
        }
        if (this.isEditMode) {
          updateBank(this.bankData)
            .then(() => {
              this.$refs.form.reset();
              this.$emit("done");
            })
            .catch((error) => {
              console.log(error);
            });
        }
      }
    },
    cancel() {
      this.$emit("cancel");
    },

    create() {
      create()
        .then((response) => {
          this.bankTypes = response.data.bankTypes;
        })
        .catch((error) => {
          console.log(error);
        });
    },
  },
  created() {
    // if (this.isAddMode) {
      this.create();
    // }
    if (this.isEditMode) {
      getBankData(this.id)
        .then((response) => {
          this.bankData = response.data;
        })
        .catch((error) => {
          console.log(error);
        });
    }
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>