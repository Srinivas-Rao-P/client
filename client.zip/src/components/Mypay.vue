<template>
  <v-row>
      <v-col>
          <div>My Pay</div>
      </v-col>
  </v-row>
</template>

<script>
export default {
    name:"mypay"
}
</script>

<style>

</style>