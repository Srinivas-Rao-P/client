!<template>
    <v-row>
      <v-col>
        <div>Reset Password</div>
      </v-col>
    </v-row>
</template>
<script>
export default {
  name: 'resetpassword',

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>