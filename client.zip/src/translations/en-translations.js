export const english = {
    theme: {
        light: "Light Mode",
        dark: "Dark Mode",
    },
    placeholders: {},
    actions: {},
    menu: {},
    messages: {},
    formLabels: {},
    navbar: {},
    privacy: {
        r: "Restricted",
        p: "Private",
        u: "Unrestricted"
    },
    resetPassword: {},
}