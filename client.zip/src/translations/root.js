import { english } from "@/translations/en-translations.js"

export const messages = {
    en: english,
}